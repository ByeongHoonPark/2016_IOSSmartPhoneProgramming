//
//  SampleData.swift
//  Rating
//
//  Created by kpugame on 2016. 4. 12..
//  Copyright © 2016년 kpugame. All rights reserved.
//

import Foundation


let playersData = [
    Player(name: "Bill Evans", game: "Tic-Tac-Toe", rating: 4),
    Player(name: "Oscar Peterson", game: "Spin the Bottle", rating: 5),
    Player(name: "Dave Brubeck", game: "Texas Hold 'em Poker", rating: 2)]